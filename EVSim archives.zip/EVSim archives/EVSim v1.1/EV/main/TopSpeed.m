function Vel_max = TopSpeed(Vel2)
% Vel is in mph (1 mph = 1.60934 kph)
%% Maximum Velocity Actual
Vel_max = max(Vel2)*1.60934;%in kph
end