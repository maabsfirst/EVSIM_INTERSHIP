str = 'F:\Vehicle Developement Data\Vehicle Matlab Input .txt';

Out = DataIO(str);