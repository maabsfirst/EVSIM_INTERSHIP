1. Give Matlab path to 'EV.prj'
2. In this folder 'EV.prj' is currently in 'EV\main\EV.prj'
3. Open 'SaveData.m' file in Matlab and run it to simulate and get the outputs from the model
4. A sample file generated from unity is also shared in this folder
5. If you want to change the path of the inputs file, change the file location in SaveData.m at line 15